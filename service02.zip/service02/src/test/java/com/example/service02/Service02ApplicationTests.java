package com.example.service02;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Service02ApplicationTests {

	@Test
	void contextLoads() {
	}

}
