package com.example.eureka_serer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EurekaSererApplication {

	public static void main(String[] args) {
		SpringApplication.run(EurekaSererApplication.class, args);
	}

}
