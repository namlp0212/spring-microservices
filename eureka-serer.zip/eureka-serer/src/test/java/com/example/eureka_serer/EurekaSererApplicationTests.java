package com.example.eureka_serer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EurekaSererApplicationTests {

	@Test
	void contextLoads() {
	}

}
